# Flutter Project

Currently working on the android -V,

Build majorly by dart(Flutter framework);

## Getting Started

For help getting started with Flutter's:
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


